package Lab5;              // Name of the package for project lab4

/**
 * This SavingsAccount class extends the super class BankAccount.
 *  
 * @author aditya
 * @version 1.0
 * @since 2018-02-24
 */

public class SavingsAccount extends BankAccount {			// Savings account inherits bankaccount

	/**
	 * Protected variable interestRate is initialized at 10% per annum.
	 */

	protected double interestRate=10;

	/**
	 * The Parametrized constructor sets the opening balance for savings account.
	 * 
	 * @param balance The opening balance for savings account.
	 */

	public SavingsAccount(double balance){								// constructor of savings account
		super(balance);
		this.balance=balance;
	}

	/**
	 * The method to calculate and update the method after adding the monthly interest.
	 * <p>
	 * Override is used to make sure that method created is part of abstract method and not a new interface.
	 * @return The updated balance after the addition of monthly fee.
	 */

	@Override
	public double calculateAndUpdateBalance() {				// static method from bankaccount class
		balance = balance + ((balance *interestRate)/12);
		return balance;
	}
}
