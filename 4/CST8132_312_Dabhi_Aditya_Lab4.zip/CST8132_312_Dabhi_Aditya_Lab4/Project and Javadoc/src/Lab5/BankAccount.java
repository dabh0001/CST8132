package Lab5;           // Name of the package for project lab4 

/**
 * This BankAccount class is an abstract class and it update the existing
 * balance and returns the updated balance.
 * 
 * @author aditya
 * @version 1.0
 * @since 2018-02-24
 */

public abstract class BankAccount {

	/**
	 * The balance of the account.
	 */

	protected double balance;	

	/**
	 * The Parametrized constructor sets the opening balance.
	 * 
	 * @param balance The opening balance.
	 */

	public BankAccount(double balance){			// constructor for bankaccount class
		this.balance= balance;

	}

	/**
	 * The method returns the Current balance of the account.
	 * 
	 * @return The Current balance.
	 */

	public double getBalance(){			// returns the value of upadted balance
		return balance;
	}

	/**
	 * This method will be overridden and implemented by concrete child classes.
	 * @return 
	 */

	public abstract double calculateAndUpdateBalance();		// abstract method for calculating and updating balance in savings and chequing

}
