package Lab5;               // Name of the package for project lab4

/**
 * This ChequingAccount class extends the super class BankAccount.
 *  
 * @author aditya
 * @version 1.0
 * @since 2018-02-24
 */

public class ChequingAccount extends BankAccount {			// chequing account inherits bankaccount

	/**
	 * Protected variable fee is initialized at $15 per month.
	 */

	protected double fee=15;	

	/**
	 * The Parametrized constructor sets the opening balance for chequing account.
	 * 
	 * @param balance The opening balance for chequing account.
	 */

	public ChequingAccount(double balance){								// constructor of chequing account
		super(balance);
		this.balance=balance;
	}

	/**
	 * The method to calculate and update the method after the deduction of fee monthly.
	 * <p>
	 * Override is used to make sure that method created is part of abstract method and not a new interface.
	 * @return The updated balance after the deduction of monthly fee.
	 */

	@Override        
	public double calculateAndUpdateBalance() {				// static method from bankaccount class
		balance = (balance - fee);
		return balance;
	}
}
