package Lab5;           // Name of the package for project lab4

import java.util.Random;            // importing Random class to assign random double balance to chequing and savings accounts

/**
 * This BankAccountTest class creates 2 chequing and savings accounts respectively with random balance between $0-$100.
 * <p>
 * Monthly fee is deducted in the chequing accounts.
 * <p>
 * Monthly interest is added to the savings accounts.
 * 
 * @author aditya
 * @version 1.0
 * @since 2018-02-24
 * @see java.util.Random
 */

public class BankAccountTest {

	private static BankAccount[] accounts ;		// array of all Bank Accounts
	//private static double[] x = new double[4];		// array of all Bank Accounts

	/**
	 * Default constructor initializing the array of BankAccount objects and assigning the opening balance for each account between $0-$100. 
	 */

	public BankAccountTest() {
		Random rand = new Random() ;

		accounts = new BankAccount[4];
		accounts[0]= new ChequingAccount(rand.nextDouble( )*(100.0));
		accounts[1]= new ChequingAccount(rand.nextDouble( )*(100.0));
		accounts[2]= new SavingsAccount(rand.nextDouble( )*(100.0));
		accounts[3]= new SavingsAccount(rand.nextDouble( )*(100.0));
	}

	/**
	 * The monthly process method calls the calculateAndUpdateBalance method of each BankAccount in the array.
	 * @param accounts An array of bank accounts.
	 */

	public void monthlyProcess(BankAccount[] accounts){	  
		for (BankAccount b : accounts){
			b.calculateAndUpdateBalance();
		}//end loop
	}

	/**
	 * The display method prints the calculateAndUpdate method of each BankAccount to print the updated balance.
	 * @param accounts An array of bank accounts.
	 */

	public void display(BankAccount[] accounts){
		for (int i=0; i<accounts.length; i++){
			System.out.println("Bank Account " + (i+1) + " : " + accounts[i].getBalance());		// Array of bank accounts to calculate and update balance
		}//end loop
	}

	/**
	 * Simulate 12 months of bank account updates by calling process and display method.
	 * 
	 * @param args Array of String arguments.
	 */

	public static void main(String[] args){
		BankAccountTest bat = new BankAccountTest() ;

		System.out.println("Initial Balances:");
		bat.display(bat.accounts);

		for(int i=1;i<=12;i++){
			System.out.println("Monthly update ");
			bat.monthlyProcess(bat.accounts);					// Calling monthlyProcess function
			bat.display(bat.accounts);                                          // Calling display function
		}
	}

}
