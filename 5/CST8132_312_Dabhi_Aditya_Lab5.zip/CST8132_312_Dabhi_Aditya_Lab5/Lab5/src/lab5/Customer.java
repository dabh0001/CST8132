package lab5;

/**
 * This class implements the same class and assigns the values to the fields related to the user.
 *
 * @author aditya
 * @version 2.0
 * @since 2018-03-27
 */
public class Customer implements Comparable<Customer>{

	private String firstName;
	private String lastName;
	private String email;
	private long phoneNum;

	/**
	 * Assigns the value to the customers bank account details
	 * @param firstName Value of first name.
	 * @param lastName Value of Last name.
	 * @param email Value of email address.
	 * @param phoneNum value of phone number.
	 */

	public Customer(String firstName, String lastName, String email, long phoneNum) {

		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.phoneNum = phoneNum;

	}

	/**
	 * Returning first and last name with a space in between.
	 * @return first and last name
	 */
	public String getName() {
		return firstName + " " + lastName;
	}
	/**
	 * All the user's details.
	 * @return User Details.
	 */
	public String toString() {

		return "Name:  " + firstName + " " + lastName + "\n"
				+ "Email: " + email + "\n"
				+ "Phone: " + phoneNum; 
	}

	/**
	 * Compare the names of the customer.
	 * @param customer Name of the customer
	 * @return Name of the Customer.
	 */
	public int compareTo(Customer customer) {

		return this.getName().compareTo(customer.getName());

	}
}
