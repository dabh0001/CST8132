package lab5;

import java.util.Scanner;
import java.text.DecimalFormat;


/**This ChequingAccount class extends the super class BankAccount.
 *
 * @author aditya
 * @version 2.0
 * @since 2018-03-27
 * @see java.util.Scanner
 * @see java.text.DecimalFormat
 */
public class ChequingAccount extends BankAccount{

	/**
	 * The default constructor calls add Bankaccount method.
	 * @throws SameAccountNumberException 
	 */ 
	public ChequingAccount() throws SameAccountNumberException{
		addBankAccount();
	}

	private Scanner input = new Scanner(System.in);
	/**
	 * Protected Double for monthly fee to be deducted from the chequing account.
	 */
	protected double monthlyFee;

	/**
	 * Prompts the user for monthly fee.
	 * @return True if account is successfully created or false.
	 * @throws SameAccountNumberException 
	 */
	@Override 
	public boolean addBankAccount() throws SameAccountNumberException{

		boolean status;

		status=super.addBankAccount();
		if(status){

			System.out.println("Enter MonthlyFee (Between $5.00 and $10.00 (inclusive)): ");
			do{
				double fee =  input.nextDouble();
				if(fee<=10 && fee>=5){
					this.monthlyFee = fee; 
				}else{
					System.out.println("Enter MonthlyFee Again: ");
				}
			}while(this.monthlyFee>10 && this.monthlyFee<5);

		}

		return status;
	}

	/**
	 * deducts the fee from the account and update the balance.
	 * @throws OverdrawnAccountException
	 */
	@Override
	public void calculateAndUpdateBalance() {
		this.balance -=this.monthlyFee;
		if(this.balance<0){
			try {
				throw new OverdrawnAccountException();
			} catch (OverdrawnAccountException ex) {
				ex.getMessage();
			}
		}

	}

	/**
	 * Prints the monthly fee.
	 * @return The concatenated string with monthly fee
	 */
	public String toString(){
		return super.toString()+ "Monthly fee: $" + this.monthlyFee;

	}
}
