package lab5;
import java.util.Scanner;
/**
 * This MainMenu class creates chequing and savings account.
 * <p>
 * Monthly fee is deducted in the chequing accounts.
 * <p>
 * Monthly interest is added to the savings accounts.
 * @author aditya
 * @version 2.0
 * @since 2018-03-27
 * @see java.util.Scanner
 * 
 */
public class MainMenu {

	/**
	 * It allows user to create, display, update and monthly update their accounts.
	 * 
	 * @param args Array of String arguments
	 * @throws SameAccountNumberException
	 * @throws InsufficientFundsException 
	 */

	public static void main(String[] args) throws SameAccountNumberException, InsufficientFundsException {

		Bank bank = new Bank("My bank", 10);
		Scanner input = new Scanner(System.in);
		char a;
		String option;
		do {

			displayMenu();

			option = input.next();
			a= option.toLowerCase().charAt(0);
			switch (a) {

			case 'a':
				bank.addBankAccount();
				break;

			case 'd':
				bank.displayAccount();
				break;

			case 'u':
				bank.updateAccount();
				break;

			case 'm':
				bank.monthlyUpdate();
				break;

			default:

				System.out.println("Please enter a valid option.");
			}


		} while (a != 'q');

		System.out.println("Have a good day!");

		input.close();
	}
	/**
	 * Displays the options menu to the user
	 */	

	public static void displayMenu() {

		System.out.println("Enter your choice:");
		System.out.println("a: Add new account");
		System.out.println("d: Display account details");
		System.out.println("u: Update account balance");
		System.out.println("m: Month-end update");
		System.out.println("q: Quit");

	}

}
