package lab5;

import java.util.InputMismatchException;
import java.util.Scanner;

/**The class helps the user to create the accounts.
 *
 * @author aditya
 * @version 2.0
 * @since 2018-03-27
 * @see java.util.InputMismatchException
 * @see java.util.Scanner
 */
public class Bank {


	private String bankName;

	/**
	 * Scanner object
	 */
	protected static Scanner userInput = new Scanner(System.in);

	/**
	 * BankAccount array object.
	 */
	protected static BankAccount [] accounts;

	/**
	 * initializing the value to numAccounts.
	 */
	protected static int numAccounts =0;

	/**
	 * initializing the value to bank size.
	 */
	protected static int bankSize =100;

	/**
	 * Assigning the value of bank name.
	 * @param bankName Name of bank.
	 */
	public Bank(String bankName) {
		this.bankName = bankName;
	}

	/**
	 * Invoking the constructor and over riding the value of bankSize.
	 * @param bankName
	 * @param bankSize 
	 */
	public Bank(String bankName, int bankSize) {
		// TODO implement overloaded Bank constructor
		this(bankName);
		this.bankSize = bankSize;

	}

	/**
	 * Allows the user to create the bank accounts.
	 * @throws SameAccountNumberException 
	 */
	public void addBankAccount() throws SameAccountNumberException {

		int x=0;
		System.err.println("Enter the number of accounts you want: ");
		numAccounts=userInput.nextInt();


		if (numAccounts >= bankSize){
			System.err.println("Invalid AccountNum.");
			return;
		}
		String accType ;
		
		System.out.println("Enter a �c� to create a new Chequing Account, or �s� to create a new Savings Account");

		do{

			accType=userInput.next();

			if(accType.toLowerCase().charAt(0)=='c')
				try{
					accounts[x] = new ChequingAccount();

				}//end try
				catch(NullPointerException e )
				{
					System.out.println(e);
				}


			else 
				if(accType.toLowerCase().charAt(0)=='s')
					try{
						accounts[x] = new SavingsAccount();
					}//end try
			catch(NullPointerException e )
			{

				System.out.println(e);
			}
				else
		System.out.println("Enter the correct account type:");
		}while(accType.toLowerCase().charAt(0)!='c'&& accType.toLowerCase().charAt(0)!='s');


		do{

			if (accounts[x].addBankAccount())
				x++;
			else
				System.out.println("You did not enetered the correct value");



		}while(x<numAccounts);

	}

	/**
	 * Display the account
	 */
	public void displayAccount() {

		// TODO implement Bank.displayAccount() error handling

		System.out.println(accounts[findAccount()]);

		if(findAccount()<=0);
		throw new IndexOutOfBoundsException();
		//accounts[findAccount()].toString();

	}

	/**
	 * Updates the account by withdrawing and depositing the amount.
	 * @throws InsufficientFundsException 
	 */
	public void updateAccount() throws InsufficientFundsException {

		System.out.println(accounts[findAccount()]);

		if(findAccount()<0)
			throw new IllegalArgumentException();
		double amount=0;
		try{
			if(findAccount()<=0);

		}
		catch(IndexOutOfBoundsException e){
			System.out.println(e);
		}
		do{
			try{
				System.out.println("Enter the amount: ");
				amount=userInput.nextDouble();
			}
			catch(InputMismatchException a){
				System.out.println(a);
			}


			if(amount<0)
				accounts[findAccount()].withdraw(amount);
			else if(amount>0)
				accounts[findAccount()].deposit(amount);    

		}while(amount!=0);            

		accounts[findAccount()].calculateAndUpdateBalance();
	}

	/**
	 * Updates the account monthly.
	 */
	public void monthlyUpdate() {
		for (BankAccount b : accounts){
			b.calculateAndUpdateBalance();
		}

	}

	/**
	 * This method searches the account in the bankaccounts.
	 * @return Account number.
	 */
	public int findAccount() {
		int accToFind=0;

		try{
			System.out.println("Enter the account number to find the account: ");
			accToFind=userInput.nextInt();
		}
		catch(InputMismatchException e){
			System.out.println(e);
		}
		return searchAccounts(accToFind);
	}

	/**
	 * This method searches the account in all the bank accounts.
	 * 
	 * @param accToFind Account Number
	 * @return The index value of the found account.
	 */
	public static int searchAccounts(int accToFind) {

		for(int x=0; x<accounts.length; x++){
			if(accToFind==accounts[x].accNumber)
				return x;
			else 
				return -1;

		}
		return -1;

	}

}
