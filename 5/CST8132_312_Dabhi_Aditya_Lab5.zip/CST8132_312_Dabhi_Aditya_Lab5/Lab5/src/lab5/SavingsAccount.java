package lab5;

import java.util.Scanner;
import java.text.DecimalFormat;

/**This SameAccountNumberException extends the super class Exception.
 *
 * @author aditya
 * @version 2.0
 * @since 2018-03-27
 * @see java.util.Scanner
 * @see java.text.DecimalFormat
 */
public class SavingsAccount extends BankAccount{

	/**
	 * The default constructor calls add Bankaccount method.
	 * @throws SameAccountNumberException Account number is same.
	 */
	public SavingsAccount() throws SameAccountNumberException{
		addBankAccount();
	}

	/**
	 * Protected Double value for monthly interest rate.
	 */
	protected double monthlyIntersrRate;

	/**
	 * Protected Double value for minimum balance.
	 */
	protected double minBalance;

	private Scanner input = new Scanner(System.in);

	/**
	 * Prompts the user for Interest rate and minimum balance.
	 * @return True if account is successfully created or false.
	 * @throws SameAccountNumberException Account number is same.
	 */
	@Override 
	public boolean addBankAccount() throws SameAccountNumberException{

		boolean status;
		status= super.addBankAccount();
		if(status){

			System.out.println("Enter Monthly Interest Rate: ");
			do{
				double fee =  input.nextDouble();
				if(fee<=1.00 && fee>=0.00){
					this.monthlyIntersrRate = fee; 
				}else{
					System.out.println("Enter Monthly Interest Rate Again: ");
				}
			}while(this.monthlyIntersrRate>1.00 && this.monthlyIntersrRate<0.00);


			do {
				System.out.println("Enter Minimum balance: ");
				minBalance =  input.nextDouble();
			}while(this.minBalance<5.0||this.minBalance>100.0);
		}
		
		return status;
	}

	/**
	 * Calculate the interest and add it to the current balance if current balance is greater than minimum balance.
	 */
	@Override
	public void calculateAndUpdateBalance() {
		if(this.balance>this.minBalance){
			this.balance+= (this.balance*this.monthlyIntersrRate);
		}
	}

	/**
	 * Prints the Interest rate and minimum balance.
	 * @return The concatenated string with monthly interest and minimum balance.
	 */
	public String toString(){
		return super.toString() + "Interest Rate: " + this.monthlyIntersrRate +"%\nMinimum Balance: " + this.minBalance;
	}
	
}

