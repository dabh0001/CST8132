package lab5;

import java.util.Scanner;
import java.text.DecimalFormat;
import java.util.InputMismatchException;


/**The class takes account number, balance and account type as input.
 * 
 * @author aditya
 * @version 2.0
 * @since 2018-03-27
 * @see java.util.Scanner
 * @see java.text.DecimalFormat
 * @see java.util.InputMismatchException
 */

public abstract class BankAccount {

	/**
	 * Protected variable accNumber takes account number as input.
	 */
	protected int accNumber;
	/**
	 * Protected variable balance takes balance as input.
	 */
	protected double balance;
	/**
	 * Protected variable accType takes account type as input.
	 */
	protected String accType;

	/**
	 * Object of class Customer.
	 */
	public Customer accHolder;

	private Scanner inp = new Scanner(System.in);

	/**
	 * This method prompts the user to enter the account number, balance in the account and account type along with
	 * their first name, last name, email and phone number.
	 * @return True if user inputs all values correctly and false if not.
	 * @throws SameAccountNumberException Account number same.
	 */
	public boolean addBankAccount() throws SameAccountNumberException {
		/**
		 * String used for first name.
		 */
		String fname;
		/**
		 * String used for last name.
		 */
		String lname;
		/**
		 * String used for email address.
		 */
		String email
		/**
		 * Long used for Phone number.
		 */;
		long phnNum;

		System.out.print("Enter the account number: ");
		this.accNumber= inp.nextInt();

		if(this.accNumber==Bank.searchAccounts(this.accNumber)){        // cheques if the account number already exists.
			throw new SameAccountNumberException();
		}


		try{
			System.out.print("Enter balance in the account: $");
			this.balance= inp.nextDouble();

		}
		catch(InputMismatchException e ){
			System.out.println("You Entered incorrect balance and the ecxpetion  is " + e);
		}


		do{
			System.out.print("Enter the account type: ");
			this.accType= inp.next();
		}while(accType.toLowerCase().charAt(0)!='c'||accType.toLowerCase().charAt(0)=='s');


		System.out.println("Enter your first name:");
		fname=inp.next();


		System.out.println("Enter your last name:");
		lname=inp.next();


		System.out.println("Enter your email:");
		email=inp.next();


		System.out.println("Enter your phone number:");
		phnNum=inp.nextLong();


		this.accHolder= new Customer(fname, lname, email, phnNum); 
		return (this.accHolder!=null);  
	}

	/**
	 * Returns the details of the account
	 * @return account details
	 */
	public String toString(){


		if(accType.toLowerCase().charAt(0)=='c'){
			return "Chequing Account " + accNumber + "\nBalance: " + balance;

		}
		if(accType.toLowerCase().charAt(0)=='s'){
			return "Savings Account " + accNumber + "\nBalance: " + balance ;

		}else
			return null;
	}     

	/**
	 * Deposits the amount in the account
	 * @param amount amount to be added
	 */
	public void deposit(double amount){

		this.balance+=amount;

	}

	/**
	 * Withdraw the amount from the account
	 * @param amount amount to withdraw
	 * @throws InsufficientFundsException 
	 */

	public void withdraw(double amount) throws InsufficientFundsException{

		if(amount>this.balance){
			throw new InsufficientFundsException();
		}else{
			if(amount<=this.balance){
				this.balance-= amount;
			}
		}

	}

	/**
	 * The method will calculate and update the account.
	 */
	public abstract void calculateAndUpdateBalance();

	/**
	 * This method returns the account number.
	 * @return Account number is returned
	 */
	public int getAccNumber(){
		return this.accNumber;
	}






}
