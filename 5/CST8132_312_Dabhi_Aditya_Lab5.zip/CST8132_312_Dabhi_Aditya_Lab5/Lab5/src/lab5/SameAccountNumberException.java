package lab5;

/**This SameAccountNumberException extends the super class Exception.
 *
 * @author aditya
 * @version 2.0
 * @since 2018-03-27
 */
public class SameAccountNumberException extends Exception{

	private static final long serialVersionUID = 1L;

	/**
	 * Default constructor passes the error message to super.
	 */
	public SameAccountNumberException() {
		super("Same Account Numbers");
	}

	/**
	 * The parameterzied constructor invokes the default constructor.
	 * @param message The message for the exception.
	 */
	public SameAccountNumberException(String message) {
		super(message);
	}


}
