public class Account {          // class Account

	private long accNumber;         //Long Variable with private access level modifier
	private Customer accHolder;     //object of class customer with private access level modifier
	private double balance;         //Double variable with private access level modifier

	public Account( long accNumber, Customer accHolder){            // constructor with long and customer as two parameters
		this.accNumber=accNumber;
		this.accHolder=accHolder;
	}

	public void deposit(double a){                                  // method deposit with parameter as double returning updated balance
		balance+= a;
	}

	public double withdraw(double a){                               // method withdraw with return type double returning the remaining balance
		// control statement
		if (balance<a){                                             // if statement to check the withdrawl amount with current balance
			System.out.println("The amount is insufficient... ");
			return balance;
		}
		else{                                                       
			System.out.println("The transaction is successfull...");
			balance-=a;
			return this.balance;
		}

	}

	public long getAccNumber(){                                     // method getAccNumber with return type Long returning account number
		return this.accNumber;
	}

	public Customer getAccHolder(){                                 // method getAccHolder 
		return this.accHolder;
	}

	public double getBalance(){                                      // method getBalance with return type Double returning the balance input by the user
		return this.balance;
	}

}
