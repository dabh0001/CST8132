public class Customer {         // class customer

	private String firstname;   //String Variable with private access level modifier
	private String lastname;    //String Variable with private access level modifier
	private long phoneNum;      //Long Variable with private access level modifier
	private String emailAddress;    //String Variable with private access level modifier

	public Customer(String a, String b){        // constructor with two parameters
		firstname=a;
		lastname=b;
	}


	public String getName(){                    // method getName with return type as String returning firstname and lastname
		return (firstname+ " " + lastname);     // returning firstname and lastname of the account holder
	}

	public Long getPhoneNumber(){               // method getPhoneNumber with return type Long returning phone number
		return phoneNum;
	}

	public void setPhoneNumber(Long phoneNum){      // method assigning phone number to the variable phoneNum
		this.phoneNum=phoneNum;
	}

	public String getEmailAddress(){                // method getEmailAddress with return type string returning phone number
		return emailAddress;               
	}

	public void setEmailAddress(String emailAddress){       // method assigning email address to the variable emailAddress
		this.emailAddress=emailAddress;
	}

}