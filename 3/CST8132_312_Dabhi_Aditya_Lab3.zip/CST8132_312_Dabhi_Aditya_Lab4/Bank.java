

import java.util.Scanner;



public class Bank {                                                 // class Bank

	private String bankName;                                    // String variable with private access level modifier
	private Account[] accounts;                                 // accounts 
	static Scanner input = new Scanner(System.in);              // Scanner variable as a scanner

	public Bank(String bankName) {                              // Constructor


		this.bankName = bankName;                           // assigning parameter value to instance variable


		System.out.println("How many account holders are there in your banking system : ");         // prompt user for number of accounts
		int a = input.nextInt();                                                                    // user input

		accounts = new Account[a];                                                                  // initialize array of accounts with size

		// accounts array

		for (int i = 0; i < accounts.length; i++) {                                                 // use a classic for loop to iterator through

			// declare local variables to use
			// to collect info about account
			String lastName, firstName, emailAddress;                                           // local String variables to collect information
			long accNumber, phoneNumber;                                                        // local Long variables to collect information about user


			String intro = "Enter details of account holder " + (i+1);                          // Information about the user of account holder
			System.out.println(intro);
			for (int j = 0; j < intro.length(); j++){
				System.out.print("=");
			}
			System.out.println();


			System.out.println("Enter account number : ");                                      // prompting user and assigning the value to accNumber
			accNumber=input.nextLong();

			System.out.println("First name");                                                   // prompting user for first and last names
			firstName= input.next();

			System.out.println("Last name");
			lastName= input.next();

			Customer c = new Customer(firstName, lastName);                                     // declaring and instantiating a new Customer


			accounts[i] = new Account(accNumber, c);                                            // declaring and instantiating a new Account


			System.out.println("Enter phone Number : ");                                        // prompting for phone number and calling setPhoneNumber method
			phoneNumber=input.nextLong();
			c.setPhoneNumber(phoneNumber);


			System.out.println("Enter Email address : ");                                       // prompting for email address and calling setEmailAddress method
			emailAddress=input.next();
			c.setEmailAddress(emailAddress);


			System.out.println("Enter opening balance : ");                                     
			double abc=input.nextLong();                                                        // prompting for opening balance and depositing the initial amount into balalnce
			accounts[i].deposit(abc);
		}		

	}


	public String getBankName() {

		return bankName;                                                            //implementing getBankName() method
	}

	public void printAccountDetails() {


		String output = bankName + "'s Banking System";                            
		System.out.println(output);
		for (int i = 0; i <= output.length(); i++)                                   // printing '*' exact number of times to the length of variable output
			System.out.print("*");
		System.out.println();


		for (Account acc : accounts) {                                               // using enhanced for loop to print account details

			Customer cust = acc.getAccHolder();                                  // local Customer variable

			// printing Account Details using setters method
			System.out.print("AccountNumber: "+ acc.getAccNumber());
			System.out.print("\tName: "+ cust.getName());
			System.out.print("\tPhone number: "+ cust.getPhoneNumber());
			System.out.print("\tEmail: "+ cust.getEmailAddress());
			System.out.print("\tBalance: "+ acc.getBalance());
			System.out.println();

		}
		System.out.println();
	}


	public static void main(String[] args) {                                            // main method


		Bank myBank;                                                                // declaring a Bank object

		System.out.println("Enter bank name:");                                     // using input from user to pass through Bank object
		myBank = new Bank(input.next());

		char option;
		do {                                                                        // do-while loop

			System.out.println("d: Deposit");
			System.out.println("w: Withdraw");
			System.out.println("p: Print all accounts");
			System.out.println("q: Quit");

			option = input.next().charAt(0);                                    // input from user

			switch (option) {                                                   // switch to let the user choose from the options available
			case 'd': case 'w':

				int x;
				System.out.println("Enter account index :");         // accounts array index from user
				x=input.nextInt();

				Account a = myBank.accounts[x];                     // inputing the index number of account in class account

				if (option == 'd') {                                // if-else to check whether user wants to deposit or withdraw

					System.out.println("Enter the deposit amount: ");
					a.deposit(input.nextDouble());
				}
				else {
					System.out.println("Enter the withdraw amount: ");
					a.withdraw(input.nextDouble());
				}

			case 'p':                                                               // option to print the details of all accounts
				myBank.printAccountDetails();
				break;
			case 'q':                                                               // option to quit the program
				break;
			default:                                                                // default for invalid option
				System.out.println("Enter a valid option.");
			}

		} while (option != 'q');                                                                // checking condition if user wants to quit

		System.out.println("Goodbye!");

		input.close();
	}
}