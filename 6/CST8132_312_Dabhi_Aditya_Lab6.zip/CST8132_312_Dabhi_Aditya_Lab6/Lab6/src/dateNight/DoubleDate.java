package dateNight;

import java.util.ArrayList;
import java.util.Random;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.JButton;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import cst8132.restaurant.Menu;
import cst8132.restaurant.Restaurant;

/**The class makes the frame for the date night.
 *
 * @author aditya
 * @version 1.0
 * @since 2018-04-27
 * @see java.util.ArrayLis
 * @see java.util.Random
 * @see javax.swing.JFrame
 * @see javax.swing.JPanel
 * @see javax.swing.JLabel
 * @see javax.swing.JTextField
 * @see javax.swing.SwingUtilities
 * @see javax.swing.JButton
 * @see java.awt.Component
 * @see java.awt.FlowLayout
 * @see java.awt.Graphics
 * @see java.awt.GridLayout
 * @see java.awt.event.ActionEvent
 * @see java.awt.event.ActionListener
 * @see cst8132.restaurant.Menu
 * @see cst8132.restaurant.Restaurant
 */


public class DoubleDate extends JFrame {

	private ArrayList<String> guests;
	private static String[] movies = new String[3];
	private String movieTitle;
	private int movieTime;
	private Restaurant restaurant;
	private Menu menu;
	private Bill bill;

	private JPanel inputPanel;
	private JPanel guestList;
	private JLabel addGuestPrompt;
	private JLabel guestListHeader;
	private JTextField newGuestName;
	private JButton addGuest;
	private JButton letsGo;



	private static Random random=new Random();


	/**
	 * Constructor creating the Layout for the double date.
	 */
	public DoubleDate() {
		super("Double Date");

		guests = new ArrayList<String>(4);

		setLayout(new GridLayout(2,2));

		addGuestPrompt=new JLabel("Enter a guest name:");
		add(addGuestPrompt);

		guestListHeader=new JLabel("Guest List");
		add(guestListHeader);

		inputPanel=new JPanel(new FlowLayout());

		newGuestName=new JTextField(20);
		inputPanel.add(newGuestName);

		addGuest=new JButton("Add Guest to List");
		addGuest.addActionListener(new AddGuestHandler());
		inputPanel.add(addGuest);

		letsGo=new JButton("Let's GO Out!");
		letsGo.addActionListener( new ActionListener() {

			public void actionPerformed( ActionEvent e ) {
				goOnDate((DoubleDate) SwingUtilities.getRoot((Component) e.getSource()));
				setVisible(false);
				dispose();
			}

		} );
		inputPanel.add(letsGo);


		letsGo.setVisible(false);

		add(inputPanel);						

		guestList=new JPanel(new FlowLayout());

		add(guestList);							

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(500, 250);


		this.restaurant = Restaurant.getInstance("Dawat");

		menu = restaurant.getMenu();

		addMenuItems();

		bill = new Bill();

		movies[0]= "The Mummy";
		movies[1]= "Notebook";
		movies[2]= "Jump Street";
	}

	/**
	 * This method set the movie and movie time. It also checks happy hour and places the order for the customer.
	 * @param date Object of the class DoubleDate.
	 */
	public void goOnDate(DoubleDate date) {

		date.movieTitle = date.pickAMovie(movies);

		date.movieTime = date.getShowing();

		date.bill.setHappyHour(date.movieTime == 10);



		for(int i = 0; i<date.guests.size(); i++) {

			date.placeOrder(date.guests.get(i),"Entrees");
			date.placeOrder(date.guests.get(i),"Drinks");

			if(i==0) {
				date.placeOrder(date.guests.get(i), "Appetizers");
				
			}
			if(i%2==0) {
				date.placeOrder(date.guests.get(i),"Desserts");

			}

		}
		System.out.println(date);

	} // end of goOnDate

	/**
	 * Returns a random movie from the list of the movies.
	 * @param movies List of movies
	 * @return a random movie
	 */
	public String pickAMovie(String[] movies) {
		return movies[random.nextInt(3)];
		
	}

	/**
	 * Returns the time of the movie randomly
	 * @return random timing for movie
	 */
	public int getShowing() {
		return (Math.random()<0.5?6:10);
		
	}

	/**
	 * This method adds the whole menu to the menu class.
	 */
	public void addMenuItems() {
		menu.addMenuItem("Drinks","Whiskey" , 7);
		menu.addMenuItem("Drinks","Beer" , 5);
		menu.addMenuItem("Drinks","Rum" , 6);

		menu.addMenuItem("Desserts","Cheese cake" , 8);
		menu.addMenuItem("Desserts","Custard" , 6);
		menu.addMenuItem("Desserts","Rice pudding" , 10);

		menu.addMenuItem("Appetizers","Chicken dip" , 16);
		menu.addMenuItem("Appetizers","Meatballs" , 20);
		menu.addMenuItem("Appetizers","Nachos" , 24);

		menu.addMenuItem("Entrees","Pizza" , 15);
		menu.addMenuItem("Entrees","Salad" , 13);
		menu.addMenuItem("Entrees","Tilapia" , 22);


	}

	/**
	 * This method place the order for the customer
	 * @param guest name of the person ordering
	 * @param itemType name of the item ordered
	 * @return returns a random order from the menu
	 */
	public boolean placeOrder(String guest, String itemType) {
		menu.getRandomMenuItem(itemType);
		return bill.addOrderItem(guest, menu.getRandomMenuItem(itemType));
	}

	/**
	 * Main method creates the object for the class.
	 * @param args Array of String arguments.
	 */
	public static void main(String[] args) {
		DoubleDate date = new DoubleDate();
		date.setVisible(true);
	}

	/**
	 * Draws onto components.
	 */
	public void paint(Graphics g) {
		super.paint(g);
	}

	/**
	 * Returns the whole output including movie, timings, menu and the bill.
	 */
	public String toString() {

		String s = "The movies we can see are: \n";
		for (String m : movies)
			s += m + "\n";

		s+= "We are going to see: " + movieTitle + " at " + movieTime + "\n";

		s +="We will be going to " + restaurant.getName() + " for our date.\n";

		if(bill.getHappyHour()) {
			s +="I will meet u there before the movie.\n";
			s +="It's happy hour! $2 off drinks, and 1/2 price appetizers!!\n";

		}
		else {
			s +="I will meet u there after the movie.\n";
			s +="We'll be missing happy hour, but we'll still be happy!\n";

		}

		s += menu.toString();
		s += bill.toString();

		return s;
	}


	private class AddGuestHandler implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {

			guests.add(newGuestName.getText());
			guestList.add(new JLabel(newGuestName.getText()));

			newGuestName.setText("");

			//4. new JLabel to the guestList Panel


			letsGo.setVisible(true);

			if(guests.size()<4)
				addGuest.setVisible(true);
			else if(guests.size()>=4)
				addGuest.setVisible(false);

			guestList.validate();

			guestList.repaint();

		}

	}

}
