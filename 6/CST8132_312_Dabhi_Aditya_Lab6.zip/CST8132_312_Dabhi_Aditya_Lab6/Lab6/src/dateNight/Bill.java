package dateNight;

import java.util.ArrayList;
import java.util.HashMap;
import 	cst8132.restaurant.Appetizer;
import 	cst8132.restaurant.Drink;
import 	cst8132.restaurant.MenuItem;

/**The class calculates the bill.
 *
 * @author aditya
 * @version 1.0
 * @since 2018-04-27
 * @see java.util.ArrayLis
 * @see java.util.HashMap
 * @see cst8132.restaurant.Appetizer
 * @see cst8132.restaurant.Drink
 * @see cst8132.restaurant.MenuItem
 */
public class Bill {
	private HashMap<String,ArrayList<MenuItem>> orders = new HashMap<String,ArrayList<MenuItem>>(4);

	protected boolean isHappyHour = false;
	private double subtotal;
	private double hstRate = 0.15;
	private final int MAX_MENU_ITEM_LENGTH = 30;


	/**
	 * This method adds order item and adds it's price to the bill.
	 * @param guest name of the customer
	 * @param item name of the item ordered
	 * @return true
	 */
	public boolean addOrderItem(String guest, MenuItem item) {

		ArrayList<MenuItem> o = orders.getOrDefault(guest, new ArrayList<MenuItem>(4));
		o.add(item);

		orders.put(guest, o);

		subtotal += item.getPrice();

		return true;
	}

	/**
	 * Checks if happy hour is still available.
	 * @return The value of the discount.
	 */
	public double getHappyHourDiscount() {

		double happyHourDiscount = 0;

		if (!isHappyHour)
			return 0;

		for (ArrayList<MenuItem> a : orders.values()) {

			for (MenuItem m : a) {

				if (m instanceof Drink) {
					happyHourDiscount += 2;
				}

				if (m instanceof Appetizer) {
					happyHourDiscount += m.getPrice() / 2;
				}

			}

		}

		return happyHourDiscount;
	}

	/**
	 * Returns the subtotal and happy hour discount with HST.
	 */
	public String toString() {

		String s = "";
		String format = "\t%-" + MAX_MENU_ITEM_LENGTH + "s \t $%6.2f\n";

		for (String o : orders.keySet()) {

			s += "Dinner Guest: " + o + "\n";

			for (MenuItem item : orders.get(o)) {
				s += String.format(format, item.getName(), item.getPrice());
			}

			s += "\n";

		}

		s += String.format(format, "Subtotal", getSubtotal());
		s += String.format(format, "Happy Hour Discount", getHappyHourDiscount());
		s += String.format(format, "HST " + (int) (hstRate * 100) + "%", getHst());

		s += String.format(format, "Total", getTotal());

		return s;
	}

	/**
	 * Returns if happyhour is still available
	 * @return
	 */
	public boolean getHappyHour() {
		return isHappyHour;
	}

	/**
	 * sets the value of happyhour
	 * @param isHappyHour
	 */
	public void setHappyHour(boolean isHappyHour) {
		this.isHappyHour=isHappyHour;
	}

	/**
	 * returns the value subtotal
	 * @return subtotal
	 */
	public double getSubtotal() {
		return this.subtotal;
	}

	/**
	 * returns the value of HST
	 * @return HST
	 */
	public double getHst() {
		double hst= (subtotal - getHappyHourDiscount()) * hstRate;
		return hst;
	}

	/**
	 * returns the HST rate.
	 * @return
	 */
	public double getHstRate() {
		return this.hstRate;
	}

	/**
	 * Returns the value of total amount.
	 * @return Total amount
	 */
	public double getTotal() {
		double total = subtotal - getHappyHourDiscount() + getHst();
		return total;
	}

}
