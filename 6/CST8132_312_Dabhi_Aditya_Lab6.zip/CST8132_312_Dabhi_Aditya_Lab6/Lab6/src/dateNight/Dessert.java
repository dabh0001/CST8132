package dateNight;

import cst8132.restaurant.MenuItem;

/**The class assigns the dessert item to the customer's bill.
 *
 * @author aditya
 * @version 1.0
 * @since 2018-04-27
 * @see cst8132.restaurant.MenuItem
 */
public class Dessert extends MenuItem{


	public Dessert(String name, double price) {
		super(name, price);
	}

}
